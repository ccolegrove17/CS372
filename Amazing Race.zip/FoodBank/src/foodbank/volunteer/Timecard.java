/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package foodbank.volunteer;

/**
 *
 * @author ccolegrove17
 */
public class Timecard {
    private int hours;
    
    public void setHours(int hours){
        this.hours = hours;
    }
    
    public int getHours(){
        return hours;
    }
}
